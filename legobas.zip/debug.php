<?php
error_reporting(E_ALL);
ini_set("display_errors",1);
include("Hemsida3.php");
?>